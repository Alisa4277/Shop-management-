# Multi-Shop Management System — Phase 1 (Foundation)

Plain HTML/CSS/JS frontend + PHP backend + MySQL. No frameworks.

## What's included in this phase

- **Database schema** (`database/schema.sql`) — roles, users, shops, employees
  (via users+role), categories, suppliers, products, inventory, stock_movements,
  activity_logs. Designed to extend cleanly into POS/sales/M-Pesa/transfers next.
- **Secure auth system** — login, logout, forgot/reset password, session-based
  RBAC, brute-force throttling, activity logging.
- **Super Admin dashboard** — live stats, low-stock alerts across all shops.
- **Shop management** — add/list/activate/deactivate shops, assign managers.
- **Product management** — add/list/search products with image upload
  (MIME-validated, randomized filenames, PHP execution blocked in `/uploads`).

## Setup

1. Create the database:
   ```
   mysql -u root -p < database/schema.sql
   ```
2. Set environment variables on your server (never hardcode credentials):
   `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`, `APP_URL`, `APP_ENV`.
3. Create your first Super Admin (generates a real bcrypt hash — do not
   hand-edit one into SQL):
   ```
   php database/create_admin.php
   ```
4. Point your web server's document root at this folder (or at `public/`
   with the other folders one level up, and adjust `APP_URL`/includes
   accordingly). `config/`, `includes/`, and `database/` are already
   locked down via `.htaccess` (Apache) — if you're on Nginx you'll need
   equivalent `location` blocks denying those paths.
5. Visit `/public/auth/login.php`.

## Security measures already in place

- Password hashing via `password_hash()` / `password_verify()` (bcrypt)
- 100% prepared statements (PDO, emulation disabled) — no raw SQL concatenation
- CSRF tokens on every state-changing form
- Output escaping via `e()` everywhere user data is rendered — XSS mitigation
- HttpOnly + SameSite session cookies, session regeneration, inactivity timeout
- Login rate-limiting/lockout
- Real MIME-type checked file uploads, randomized filenames, PHP execution
  disabled inside `/uploads`
- Activity logs for login, logout, failed logins, shop/product changes
- `config/`, `includes/`, `database/` blocked from direct web access

## Not yet built (next phases)

- POS + cart + discount engine + discount-permission escalation
- M-Pesa Daraja STK Push integration (needs your real Daraja credentials —
  I can write the integration code, but can't test live calls from here)
- Stock transfers between shops
- Customers, suppliers CRUD screens, expenses, employee management screens
- Reports (PDF/Excel export) and dashboard charts (Chart.js)
- Receipt generation
- Manager/Cashier/Storekeeper dashboards (nav links already wired in `includes/sidebar.php`, pages not built yet)

Say the word and I'll build the next phase — POS + discounts is the natural
next step since sales are the core of the system.
