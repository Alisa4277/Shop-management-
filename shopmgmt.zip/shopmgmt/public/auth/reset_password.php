<?php
require_once __DIR__ . '/../../config/config.php';

$token = (string) ($_GET['token'] ?? $_POST['token'] ?? '');

if ($token === '') {
    flash_set('error', 'Invalid or missing reset token.');
    redirect('/public/auth/forgot_password.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $password = (string) ($_POST['password'] ?? '');
    $confirm  = (string) ($_POST['password_confirm'] ?? '');

    if (strlen($password) < 8) {
        flash_set('error', 'Password must be at least 8 characters.');
    } elseif ($password !== $confirm) {
        flash_set('error', 'Passwords do not match.');
    } elseif (reset_password($token, $password)) {
        flash_set('success', 'Password updated. You can now log in.');
        redirect('/public/auth/login.php');
    } else {
        flash_set('error', 'This reset link is invalid or has expired.');
    }
    redirect('/public/auth/reset_password.php?token=' . urlencode($token));
}

$flashes = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reset Password — <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="card auth-card">
    <div class="brand">🏬 <?= e(APP_NAME) ?></div>
    <?php foreach ($flashes as $f): ?>
      <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
    <?php endforeach; ?>
    <form method="POST">
      <?= csrf_field() ?>
      <input type="hidden" name="token" value="<?= e($token) ?>">
      <div class="form-group">
        <label for="password">New Password</label>
        <input type="password" id="password" name="password" required minlength="8">
      </div>
      <div class="form-group">
        <label for="password_confirm">Confirm Password</label>
        <input type="password" id="password_confirm" name="password_confirm" required minlength="8">
      </div>
      <button type="submit" class="btn btn-block">Reset Password</button>
    </form>
  </div>
</div>
</body>
</html>
