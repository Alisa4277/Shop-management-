<?php
require_once __DIR__ . '/../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/public/auth/login.php');
}

csrf_verify();

$email    = trim((string) ($_POST['email'] ?? ''));
$password = (string) ($_POST['password'] ?? '');
$portal   = (string) ($_POST['portal'] ?? '');

$validPortals = ['super_admin', 'shop_manager', 'cashier', 'storekeeper'];
if (!in_array($portal, $validPortals, true)) {
    $portal = 'super_admin';
}

if ($email === '' || $password === '') {
    flash_set('error', 'Please enter both email and password.');
    redirect('/public/auth/login.php');
}

$result = attempt_login($email, $password);

if (!$result['success']) {
    flash_set('error', $result['message']);
    redirect('/public/auth/login.php');
}

// The credentials were valid, but make sure the account actually holds the
// role the person selected on the login screen — prevents a cashier account
// from landing on the manager portal (or worse, someone probing which
// portal a known email belongs to).
if ($result['role'] !== $portal) {
    log_activity($_SESSION['user_id'] ?? null, 'portal_mismatch', "Login succeeded but selected portal '{$portal}' did not match account role '{$result['role']}'");
    logout();
    flash_set('error', 'Your account is not registered for that portal. Please select the correct sign-in option.');
    redirect('/public/auth/login.php');
}

redirect(dashboard_path_for_role($result['role']));
