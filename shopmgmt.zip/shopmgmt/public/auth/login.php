<?php
require_once __DIR__ . '/../../config/config.php';

if (is_logged_in()) {
    redirect(dashboard_path_for_role($_SESSION['role']));
}

$flashes = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="card auth-card">
    <div class="brand">🏬 <?= e(APP_NAME) ?></div>

    <?php if (!empty($_GET['timeout'])): ?>
      <div class="flash flash-info">You were logged out due to inactivity.</div>
    <?php endif; ?>

    <?php foreach ($flashes as $f): ?>
      <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
    <?php endforeach; ?>

    <form method="POST" action="<?= APP_URL ?>/public/auth/login_process.php">
      <?= csrf_field() ?>

      <div class="form-group">
        <label>I am signing in as</label>
        <div class="portal-tabs">
          <label class="portal-tab">
            <input type="radio" name="portal" value="super_admin" checked>
            <span>👑 Super Admin</span>
          </label>
          <label class="portal-tab">
            <input type="radio" name="portal" value="shop_manager">
            <span>🏬 Shop Manager</span>
          </label>
          <label class="portal-tab">
            <input type="radio" name="portal" value="cashier">
            <span>🧾 Cashier</span>
          </label>
          <label class="portal-tab">
            <input type="radio" name="portal" value="storekeeper">
            <span>📦 Storekeeper</span>
          </label>
        </div>
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required autofocus>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required minlength="8">
      </div>
      <button type="submit" class="btn btn-block">Sign In</button>
    </form>

    <p style="text-align:center; margin-top:16px; font-size:0.85rem;">
      <a href="<?= APP_URL ?>/public/auth/forgot_password.php">Forgot your password?</a>
    </p>
  </div>
</div>
</body>
</html>
