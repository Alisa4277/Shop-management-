<?php
require_once __DIR__ . '/../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $email = trim((string) ($_POST['email'] ?? ''));

    if ($email !== '') {
        $token = create_password_reset($email);
        if ($token !== null) {
            // TODO: send via email/SMS provider instead of exposing here.
            // For local development only, the reset link is logged server-side.
            error_log("Password reset link for {$email}: " . APP_URL . "/public/auth/reset_password.php?token={$token}");
        }
    }
    // Same message regardless of whether the email exists — avoids leaking
    // which addresses are registered in the system.
    flash_set('success', 'If that email exists in our system, a reset link has been sent.');
    redirect('/public/auth/forgot_password.php');
}

$flashes = flash_get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password — <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="card auth-card">
    <div class="brand">🏬 <?= e(APP_NAME) ?></div>
    <?php foreach ($flashes as $f): ?>
      <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
    <?php endforeach; ?>
    <form method="POST">
      <?= csrf_field() ?>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required autofocus>
      </div>
      <button type="submit" class="btn btn-block">Send Reset Link</button>
    </form>
    <p style="text-align:center; margin-top:16px; font-size:0.85rem;">
      <a href="<?= APP_URL ?>/public/auth/login.php">Back to login</a>
    </p>
  </div>
</div>
</body>
</html>
