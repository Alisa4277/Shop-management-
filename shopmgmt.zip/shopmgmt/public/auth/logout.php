<?php
require_once __DIR__ . '/../../config/config.php';

logout();
redirect('/public/auth/login.php');
