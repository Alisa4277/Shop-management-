<?php
require_once __DIR__ . '/../config/config.php';

if (is_logged_in()) {
    redirect(dashboard_path_for_role($_SESSION['role']));
}
redirect('/public/auth/login.php');
