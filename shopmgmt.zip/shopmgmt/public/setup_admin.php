<?php
require_once __DIR__ . '/../config/config.php';

/**
 * One-time web-based Super Admin creation for hosts without SSH access.
 * Visit: /public/setup_admin.php?key=YOUR_SETUP_KEY
 *
 * Protections:
 *  - Requires the SETUP_KEY set in config/local.php (or real env var) to match
 *  - Refuses to run at all once a super_admin already exists
 *  - Delete this file (or your SETUP_KEY) once you're done — it's dead
 *    weight and a bigger attack surface than leaving it in place forever.
 */

$configuredKey = getenv('SETUP_KEY') ?: '';
$suppliedKey = (string) ($_GET['key'] ?? $_POST['key'] ?? '');

if ($configuredKey === '' || $configuredKey === 'change-this-to-a-long-random-string') {
    die('Set a real SETUP_KEY in config/local.php before using this page.');
}
if (!hash_equals($configuredKey, $suppliedKey)) {
    http_response_code(403);
    die('Invalid or missing setup key.');
}

$pdo = db();
$existingAdmin = $pdo->query(
    "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE r.name = 'super_admin' LIMIT 1"
)->fetch();

if ($existingAdmin) {
    die('A Super Admin account already exists. This setup page is now disabled. Delete public/setup_admin.php.');
}

$error = null;
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $fullName = trim((string) ($_POST['full_name'] ?? ''));
    $email    = trim((string) ($_POST['email'] ?? ''));
    $phone    = trim((string) ($_POST['phone'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if ($fullName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) {
        $error = 'Please fill in all fields with a valid email and a password of at least 8 characters.';
    } else {
        $role = $pdo->prepare("SELECT id FROM roles WHERE name = 'super_admin'");
        $role->execute();
        $roleRow = $role->fetch();

        if (!$roleRow) {
            $error = "Role 'super_admin' not found — did you import database/schema.sql?";
        } else {
            $pdo->prepare(
                "INSERT INTO users (employee_code, full_name, email, phone, password_hash, role_id, shop_id, status)
                 VALUES ('ADM-0001', :name, :email, :phone, :hash, :role_id, NULL, 'active')"
            )->execute([
                'name'    => $fullName,
                'email'   => $email,
                'phone'   => $phone,
                'hash'    => password_hash($password, PASSWORD_DEFAULT),
                'role_id' => $roleRow['id'],
            ]);
            $success = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Setup — <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="auth-wrap">
  <div class="card auth-card">
    <div class="brand">🏬 First-Time Setup</div>

    <?php if ($success): ?>
      <div class="flash flash-success">
        Super Admin account created. <strong>Delete public/setup_admin.php now</strong>,
        then <a href="<?= APP_URL ?>/public/auth/login.php">log in here</a>.
      </div>
    <?php else: ?>
      <?php if ($error): ?>
        <div class="flash flash-error"><?= e($error) ?></div>
      <?php endif; ?>
      <form method="POST">
        <?= csrf_field() ?>
        <input type="hidden" name="key" value="<?= e($suppliedKey) ?>">
        <div class="form-group"><label>Full Name</label><input type="text" name="full_name" required></div>
        <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
        <div class="form-group"><label>Phone</label><input type="tel" name="phone"></div>
        <div class="form-group"><label>Password (min 8 chars)</label><input type="password" name="password" required minlength="8"></div>
        <button type="submit" class="btn btn-block">Create Super Admin</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
