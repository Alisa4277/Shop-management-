<?php
require_once __DIR__ . '/../../config/config.php';
require_role(['super_admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/public/admin/shops.php');
}
csrf_verify();

$name        = trim((string) ($_POST['name'] ?? ''));
$shopCode    = trim((string) ($_POST['shop_code'] ?? ''));
$location    = trim((string) ($_POST['location'] ?? ''));
$phone       = trim((string) ($_POST['phone'] ?? '')) ?: null;
$email       = trim((string) ($_POST['email'] ?? '')) ?: null;
$openingDate = trim((string) ($_POST['opening_date'] ?? '')) ?: null;
$managerId   = !empty($_POST['manager_id']) ? (int) $_POST['manager_id'] : null;

if ($name === '' || $shopCode === '' || $location === '') {
    flash_set('error', 'Shop name, code, and location are required.');
    redirect('/public/admin/shops.php');
}

if ($email !== null && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    flash_set('error', 'Please enter a valid email address.');
    redirect('/public/admin/shops.php');
}

try {
    $pdo = db();
    $pdo->prepare(
        "INSERT INTO shops (shop_code, name, location, phone, email, manager_id, opening_date, status)
         VALUES (:code, :name, :location, :phone, :email, :manager_id, :opening_date, 'active')"
    )->execute([
        'code'         => $shopCode,
        'name'         => $name,
        'location'     => $location,
        'phone'        => $phone,
        'email'        => $email,
        'manager_id'   => $managerId,
        'opening_date' => $openingDate,
    ]);

    $newShopId = (int) $pdo->lastInsertId();
    log_activity(current_user()['id'], 'shop_created', "Created shop '{$name}' (ID {$newShopId})");
    flash_set('success', "Shop '{$name}' created successfully.");
} catch (PDOException $e) {
    if ($e->getCode() === '23000') {
        flash_set('error', 'A shop with that code already exists.');
    } else {
        error_log('shop_save error: ' . $e->getMessage());
        flash_set('error', 'Could not create the shop. Please try again.');
    }
}

redirect('/public/admin/shops.php');
