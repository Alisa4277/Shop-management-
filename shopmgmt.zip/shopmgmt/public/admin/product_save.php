<?php
require_once __DIR__ . '/../../config/config.php';
require_role(['super_admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/public/admin/products.php');
}
csrf_verify();

$name          = trim((string) ($_POST['name'] ?? ''));
$sku           = trim((string) ($_POST['sku'] ?? ''));
$barcode       = trim((string) ($_POST['barcode'] ?? '')) ?: null;
$categoryId    = !empty($_POST['category_id']) ? (int) $_POST['category_id'] : null;
$buyingPrice   = (float) ($_POST['buying_price'] ?? 0);
$sellingPrice  = (float) ($_POST['selling_price'] ?? 0);
$minStock      = (int) ($_POST['min_stock_level'] ?? 5);
$description   = trim((string) ($_POST['description'] ?? '')) ?: null;

if ($name === '' || $sku === '' || $buyingPrice < 0 || $sellingPrice < 0) {
    flash_set('error', 'Please fill in all required fields with valid values.');
    redirect('/public/admin/products.php');
}

// ---- Safe image upload handling ----
$imagePath = null;
if (!empty($_FILES['image']['name'])) {
    $file = $_FILES['image'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        flash_set('error', 'Image upload failed. Please try again.');
        redirect('/public/admin/products.php');
    }

    // Validate real MIME type (not just the extension) to prevent disguised uploads
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowed[$mime])) {
        flash_set('error', 'Only JPG, PNG, or WEBP images are allowed.');
        redirect('/public/admin/products.php');
    }

    if ($file['size'] > 3 * 1024 * 1024) { // 3MB limit
        flash_set('error', 'Image must be smaller than 3MB.');
        redirect('/public/admin/products.php');
    }

    $ext = $allowed[$mime];
    $filename = bin2hex(random_bytes(16)) . '.' . $ext; // random name — never trust user filename
    $destination = UPLOAD_DIR . 'products/' . $filename;

    if (!is_dir(UPLOAD_DIR . 'products')) {
        mkdir(UPLOAD_DIR . 'products', 0755, true);
    }

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        $imagePath = 'products/' . $filename;
    }
}

try {
    $pdo = db();
    $pdo->prepare(
        "INSERT INTO products (sku, barcode, name, category_id, description, image_path, buying_price, selling_price, min_stock_level, status)
         VALUES (:sku, :barcode, :name, :category_id, :description, :image_path, :buying_price, :selling_price, :min_stock, 'active')"
    )->execute([
        'sku'           => $sku,
        'barcode'       => $barcode,
        'name'          => $name,
        'category_id'   => $categoryId,
        'description'   => $description,
        'image_path'    => $imagePath,
        'buying_price'  => $buyingPrice,
        'selling_price' => $sellingPrice,
        'min_stock'     => $minStock,
    ]);

    log_activity(current_user()['id'], 'product_created', "Created product '{$name}' (SKU {$sku})");
    flash_set('success', "Product '{$name}' added successfully.");
} catch (PDOException $e) {
    if ($e->getCode() === '23000') {
        flash_set('error', 'A product with that SKU or barcode already exists.');
    } else {
        error_log('product_save error: ' . $e->getMessage());
        flash_set('error', 'Could not add the product. Please try again.');
    }
}

redirect('/public/admin/products.php');
