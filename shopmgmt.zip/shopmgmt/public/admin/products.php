<?php
require_once __DIR__ . '/../../config/config.php';
require_role(['super_admin']);

$pdo = db();

$search = trim((string) ($_GET['q'] ?? ''));
$sql = "SELECT p.*, c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        WHERE 1=1";
$params = [];
if ($search !== '') {
    $sql .= " AND (p.name LIKE :q OR p.sku LIKE :q OR p.barcode LIKE :q)";
    $params['q'] = "%{$search}%";
}
$sql .= " ORDER BY p.created_at DESC LIMIT 100";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

$activePage = 'products';
$pageTitle = 'Products';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> — <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="app-shell">
  <?php include __DIR__ . '/../../includes/sidebar.php'; ?>
  <main class="main-content">
    <?php include __DIR__ . '/../../includes/topbar.php'; ?>

    <div class="card" style="margin-bottom:20px; display:flex; justify-content:space-between; align-items:center;">
      <div>
        <strong>Adding many products?</strong>
        <p style="margin:4px 0 0; color:var(--text-muted); font-size:0.85rem;">Upload a CSV or Excel file to add products in bulk instead of one at a time.</p>
      </div>
      <a href="<?= APP_URL ?>/public/admin/product_import.php" class="btn btn-outline">Bulk Import</a>
    </div>

    <div class="card" style="margin-bottom:20px;">
      <h3 style="margin-top:0;">Add Product</h3>
      <form method="POST" action="<?= APP_URL ?>/public/admin/product_save.php" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="stat-grid">
          <div class="form-group"><label>Product Name</label><input type="text" name="name" required></div>
          <div class="form-group"><label>SKU</label><input type="text" name="sku" required></div>
          <div class="form-group"><label>Barcode</label><input type="text" name="barcode"></div>
          <div class="form-group">
            <label>Category</label>
            <select name="category_id">
              <option value="">— None —</option>
              <?php foreach ($categories as $c): ?>
                <option value="<?= (int) $c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group"><label>Buying Price (KSh)</label><input type="number" step="0.01" min="0" name="buying_price" required></div>
          <div class="form-group"><label>Selling Price (KSh)</label><input type="number" step="0.01" min="0" name="selling_price" required></div>
          <div class="form-group"><label>Minimum Stock Level</label><input type="number" min="0" name="min_stock_level" value="5"></div>
          <div class="form-group"><label>Product Image</label><input type="file" name="image" accept="image/*"></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description" rows="2"></textarea></div>
        <button type="submit" class="btn">Add Product</button>
      </form>
    </div>

    <div class="card">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <h3 style="margin:0;">All Products</h3>
        <form method="GET" style="display:flex; gap:8px;">
          <input type="text" name="q" placeholder="Search name, SKU, barcode..." value="<?= e($search) ?>" style="width:240px;">
          <button type="submit" class="btn btn-outline">Search</button>
        </form>
      </div>
      <table>
        <thead>
          <tr><th>SKU</th><th>Name</th><th>Category</th><th>Buying</th><th>Selling</th><th>Min Stock</th><th>Status</th></tr>
        </thead>
        <tbody>
          <?php if (empty($products)): ?>
            <tr><td colspan="7" style="color:var(--text-muted);">No products found.</td></tr>
          <?php endif; ?>
          <?php foreach ($products as $p): ?>
            <tr>
              <td><?= e($p['sku']) ?></td>
              <td><?= e($p['name']) ?></td>
              <td><?= e($p['category_name'] ?? '—') ?></td>
              <td><?= format_money((float) $p['buying_price']) ?></td>
              <td><?= format_money((float) $p['selling_price']) ?></td>
              <td><?= (int) $p['min_stock_level'] ?></td>
              <td>
                <span class="badge <?= $p['status'] === 'active' ? 'badge-success' : 'badge-danger' ?>">
                  <?= e(ucfirst($p['status'])) ?>
                </span>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>
