<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../includes/product_import.php';
require_role(['super_admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/public/admin/product_import.php');
}
csrf_verify();

if (empty($_FILES['file']['name']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    flash_set('error', 'Please choose a valid CSV or Excel file to upload.');
    redirect('/public/admin/product_import.php');
}

$file = $_FILES['file'];

if ($file['size'] > 5 * 1024 * 1024) { // 5MB cap
    flash_set('error', 'File is too large (max 5MB).');
    redirect('/public/admin/product_import.php');
}

$originalName = $file['name'];
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

if (!in_array($ext, ['csv', 'xlsx'], true)) {
    flash_set('error', 'Only .csv and .xlsx files are supported.');
    redirect('/public/admin/product_import.php');
}

// Move to a temp path with a safe name before parsing — never trust the
// original filename or rely on tmp_name's original extension.
$safeTmpPath = sys_get_temp_dir() . '/import_' . bin2hex(random_bytes(8)) . '.' . $ext;
if (!move_uploaded_file($file['tmp_name'], $safeTmpPath)) {
    flash_set('error', 'Could not process the uploaded file. Please try again.');
    redirect('/public/admin/product_import.php');
}

try {
    $rows = $ext === 'csv' ? parse_csv_file($safeTmpPath) : parse_xlsx_file($safeTmpPath);
} catch (Throwable $e) {
    @unlink($safeTmpPath);
    flash_set('error', $e->getMessage());
    redirect('/public/admin/product_import.php');
}
@unlink($safeTmpPath);

if (empty($rows)) {
    flash_set('error', 'No data rows were found in the file.');
    redirect('/public/admin/product_import.php');
}

if (count($rows) > 2000) {
    flash_set('error', 'Please import at most 2000 rows at a time.');
    redirect('/public/admin/product_import.php');
}

$pdo = db();
$results = ['total' => count($rows), 'imported' => 0, 'skipped' => 0, 'errors' => []];

$pdo->beginTransaction();
try {
    foreach ($rows as $i => $row) {
        $outcome = import_product_row($pdo, $row);
        match ($outcome['status']) {
            'imported' => $results['imported']++,
            'skipped'  => $results['skipped']++,
            default    => $results['errors'][] = ['row' => $i + 2, 'message' => $outcome['message']], // +2: header row + 1-index
        };
    }
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('Bulk import failed: ' . $e->getMessage());
    flash_set('error', 'Import failed and was rolled back. No products were added.');
    redirect('/public/admin/product_import.php');
}

$errorCount = count($results['errors']);
log_activity(
    current_user()['id'],
    'products_bulk_imported',
    "Imported {$results['imported']} products, skipped {$results['skipped']}, {$errorCount} errors (source: {$originalName})"
);

$_SESSION['import_results'] = $results;
flash_set('success', "Import complete: {$results['imported']} added, {$results['skipped']} skipped, {$errorCount} errors.");
redirect('/public/admin/product_import.php');
