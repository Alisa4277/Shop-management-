<?php
require_once __DIR__ . '/../../config/config.php';
require_role(['super_admin']);

$importResults = $_SESSION['import_results'] ?? null;
unset($_SESSION['import_results']);

$activePage = 'products';
$pageTitle = 'Bulk Import Products';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> — <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="app-shell">
  <?php include __DIR__ . '/../../includes/sidebar.php'; ?>
  <main class="main-content">
    <?php include __DIR__ . '/../../includes/topbar.php'; ?>

    <div class="card" style="margin-bottom:20px;">
      <h3 style="margin-top:0;">Bulk Import Products</h3>
      <p style="color:var(--text-muted); font-size:0.9rem;">
        Upload a CSV or Excel (.xlsx) file to add many products at once.
        Columns required: <code>sku, barcode, name, category_name, description,
        buying_price, selling_price, min_stock_level</code>. Existing SKUs are
        skipped, not overwritten — use the normal edit screen to update a
        product that already exists.
      </p>
      <p style="font-size:0.85rem;">
        <a href="<?= APP_URL ?>/public/admin/product_import_template.csv" download>⬇ Download CSV template</a>
      </p>

      <form method="POST" action="<?= APP_URL ?>/public/admin/product_import_process.php" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="form-group">
          <label for="file">CSV or Excel file</label>
          <input type="file" id="file" name="file" accept=".csv,.xlsx" required>
        </div>
        <button type="submit" class="btn">Upload &amp; Import</button>
      </form>
    </div>

    <?php if ($importResults): ?>
      <div class="card">
        <h3 style="margin-top:0;">Import Results</h3>
        <div class="stat-grid" style="margin-bottom:16px;">
          <div class="card stat-card">
            <span class="label">Rows Processed</span>
            <span class="value"><?= (int) $importResults['total'] ?></span>
          </div>
          <div class="card stat-card">
            <span class="label" style="color:var(--success)">Imported</span>
            <span class="value" style="color:var(--success)"><?= (int) $importResults['imported'] ?></span>
          </div>
          <div class="card stat-card">
            <span class="label" style="color:var(--warning)">Skipped</span>
            <span class="value" style="color:var(--warning)"><?= (int) $importResults['skipped'] ?></span>
          </div>
          <div class="card stat-card">
            <span class="label" style="color:var(--danger)">Errors</span>
            <span class="value" style="color:var(--danger)"><?= count($importResults['errors']) ?></span>
          </div>
        </div>

        <?php if (!empty($importResults['errors'])): ?>
          <table>
            <thead><tr><th>Row</th><th>Issue</th></tr></thead>
            <tbody>
              <?php foreach ($importResults['errors'] as $err): ?>
                <tr><td><?= (int) $err['row'] ?></td><td><?= e($err['message']) ?></td></tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </main>
</div>
</body>
</html>
