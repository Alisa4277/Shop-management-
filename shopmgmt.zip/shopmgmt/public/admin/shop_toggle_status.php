<?php
require_once __DIR__ . '/../../config/config.php';
require_role(['super_admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/public/admin/shops.php');
}
csrf_verify();

$shopId = (int) ($_POST['shop_id'] ?? 0);
if ($shopId <= 0) {
    redirect('/public/admin/shops.php');
}

$pdo = db();
$stmt = $pdo->prepare("SELECT status, name FROM shops WHERE id = :id");
$stmt->execute(['id' => $shopId]);
$shop = $stmt->fetch();

if (!$shop) {
    flash_set('error', 'Shop not found.');
    redirect('/public/admin/shops.php');
}

$newStatus = $shop['status'] === 'active' ? 'inactive' : 'active';
$pdo->prepare("UPDATE shops SET status = :status WHERE id = :id")
    ->execute(['status' => $newStatus, 'id' => $shopId]);

log_activity(current_user()['id'], 'shop_status_changed', "Shop '{$shop['name']}' set to {$newStatus}");
flash_set('success', "Shop status updated to {$newStatus}.");
redirect('/public/admin/shops.php');
