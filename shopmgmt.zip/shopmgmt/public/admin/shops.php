<?php
require_once __DIR__ . '/../../config/config.php';
require_role(['super_admin']);

$pdo = db();

$shops = $pdo->query(
    "SELECT s.*, u.full_name AS manager_name
     FROM shops s
     LEFT JOIN users u ON u.id = s.manager_id
     ORDER BY s.created_at DESC"
)->fetchAll();

$managers = $pdo->query(
    "SELECT u.id, u.full_name FROM users u
     JOIN roles r ON r.id = u.role_id
     WHERE r.name = 'shop_manager' AND u.status = 'active'
     ORDER BY u.full_name"
)->fetchAll();

$activePage = 'shops';
$pageTitle = 'Shops';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> — <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="app-shell">
  <?php include __DIR__ . '/../../includes/sidebar.php'; ?>
  <main class="main-content">
    <?php include __DIR__ . '/../../includes/topbar.php'; ?>

    <div class="card" style="margin-bottom:20px;">
      <h3 style="margin-top:0;">Add New Shop</h3>
      <form method="POST" action="<?= APP_URL ?>/public/admin/shop_save.php">
        <?= csrf_field() ?>
        <div class="stat-grid">
          <div class="form-group"><label>Shop Name</label><input type="text" name="name" required></div>
          <div class="form-group"><label>Shop Code</label><input type="text" name="shop_code" required placeholder="e.g. NRB-01"></div>
          <div class="form-group"><label>Location</label><input type="text" name="location" required></div>
          <div class="form-group"><label>Phone</label><input type="tel" name="phone"></div>
          <div class="form-group"><label>Email</label><input type="email" name="email"></div>
          <div class="form-group"><label>Opening Date</label><input type="date" name="opening_date"></div>
          <div class="form-group">
            <label>Assign Manager</label>
            <select name="manager_id">
              <option value="">— Unassigned —</option>
              <?php foreach ($managers as $m): ?>
                <option value="<?= (int) $m['id'] ?>"><?= e($m['full_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <button type="submit" class="btn">Add Shop</button>
      </form>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">All Shops</h3>
      <table>
        <thead>
          <tr><th>Code</th><th>Name</th><th>Location</th><th>Manager</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach ($shops as $shop): ?>
            <tr>
              <td><?= e($shop['shop_code']) ?></td>
              <td><?= e($shop['name']) ?></td>
              <td><?= e($shop['location']) ?></td>
              <td><?= e($shop['manager_name'] ?? '—') ?></td>
              <td>
                <span class="badge <?= $shop['status'] === 'active' ? 'badge-success' : 'badge-danger' ?>">
                  <?= e(ucfirst($shop['status'])) ?>
                </span>
              </td>
              <td>
                <form method="POST" action="<?= APP_URL ?>/public/admin/shop_toggle_status.php" style="display:inline;">
                  <?= csrf_field() ?>
                  <input type="hidden" name="shop_id" value="<?= (int) $shop['id'] ?>">
                  <button type="submit" class="btn btn-outline" style="padding:4px 10px; font-size:0.8rem;">
                    <?= $shop['status'] === 'active' ? 'Deactivate' : 'Activate' ?>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>
