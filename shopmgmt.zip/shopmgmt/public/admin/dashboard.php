<?php
require_once __DIR__ . '/../../config/config.php';
require_role(['super_admin']);

$pdo = db();

$totalShops = (int) $pdo->query("SELECT COUNT(*) c FROM shops WHERE status = 'active'")->fetch()['c'];
$totalProducts = (int) $pdo->query("SELECT COUNT(*) c FROM products WHERE status = 'active'")->fetch()['c'];
$totalUsers = (int) $pdo->query("SELECT COUNT(*) c FROM users WHERE status = 'active'")->fetch()['c'];

$lowStock = $pdo->query(
    "SELECT p.name, s.name AS shop_name, i.quantity, p.min_stock_level
     FROM inventory i
     JOIN products p ON p.id = i.product_id
     JOIN shops s ON s.id = i.shop_id
     WHERE i.quantity <= p.min_stock_level
     ORDER BY i.quantity ASC
     LIMIT 10"
)->fetchAll();

$activePage = 'dashboard';
$pageTitle = 'Business Overview';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> — <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<div class="app-shell">
  <?php include __DIR__ . '/../../includes/sidebar.php'; ?>
  <main class="main-content">
    <?php include __DIR__ . '/../../includes/topbar.php'; ?>

    <div class="stat-grid">
      <div class="card stat-card">
        <span class="label">Active Shops</span>
        <span class="value"><?= $totalShops ?></span>
      </div>
      <div class="card stat-card">
        <span class="label">Active Products</span>
        <span class="value"><?= $totalProducts ?></span>
      </div>
      <div class="card stat-card">
        <span class="label">Active Users</span>
        <span class="value"><?= $totalUsers ?></span>
      </div>
      <div class="card stat-card">
        <span class="label">Low Stock Alerts</span>
        <span class="value" style="color:var(--danger)"><?= count($lowStock) ?></span>
      </div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Low Stock Products (across all shops)</h3>
      <table>
        <thead>
          <tr><th>Product</th><th>Shop</th><th>Current Qty</th><th>Min Level</th></tr>
        </thead>
        <tbody>
          <?php if (empty($lowStock)): ?>
            <tr><td colspan="4" style="color:var(--text-muted);">No low-stock products right now.</td></tr>
          <?php endif; ?>
          <?php foreach ($lowStock as $row): ?>
            <tr>
              <td><?= e($row['name']) ?></td>
              <td><?= e($row['shop_name']) ?></td>
              <td><?= (int) $row['quantity'] ?></td>
              <td><?= (int) $row['min_stock_level'] ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>
