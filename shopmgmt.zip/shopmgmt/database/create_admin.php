<?php
declare(strict_types=1);

/**
 * Run this ONCE from the command line after importing schema.sql, to create
 * the first Super Admin account with a properly generated password hash.
 *
 *   php database/create_admin.php
 *
 * Do not expose this script over the web — it's a CLI setup tool only.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    die('This script can only be run from the command line.');
}

require_once __DIR__ . '/../config/database.php';

function prompt(string $label, bool $hidden = false): string
{
    echo $label;
    if ($hidden && stripos(PHP_OS, 'WIN') === false) {
        system('stty -echo');
        $value = trim(fgets(STDIN));
        system('stty echo');
        echo "\n";
    } else {
        $value = trim(fgets(STDIN));
    }
    return $value;
}

echo "=== Multi-Shop Management System — Create Super Admin ===\n";
$fullName = prompt('Full name: ');
$email    = prompt('Email: ');
$phone    = prompt('Phone: ');
$password = prompt('Password (min 8 chars): ', true);

if (strlen($password) < 8) {
    die("Password must be at least 8 characters.\n");
}

$pdo = db();

$stmt = $pdo->prepare('SELECT id FROM roles WHERE name = :n');
$stmt->execute(['n' => 'super_admin']);
$role = $stmt->fetch();
if (!$role) {
    die("Role 'super_admin' not found — did you import schema.sql first?\n");
}

$exists = $pdo->prepare('SELECT id FROM users WHERE email = :e');
$exists->execute(['e' => $email]);
if ($exists->fetch()) {
    die("A user with that email already exists.\n");
}

$hash = password_hash($password, PASSWORD_DEFAULT);

$pdo->prepare(
    'INSERT INTO users (employee_code, full_name, email, phone, password_hash, role_id, shop_id, status)
     VALUES (:code, :name, :email, :phone, :hash, :role_id, NULL, "active")'
)->execute([
    'code'    => 'ADM-0001',
    'name'    => $fullName,
    'email'   => $email,
    'phone'   => $phone,
    'hash'    => $hash,
    'role_id' => $role['id'],
]);

echo "Super Admin created successfully. You can now log in at /public/auth/login.php\n";
