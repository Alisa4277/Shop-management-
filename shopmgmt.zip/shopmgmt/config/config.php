<?php
declare(strict_types=1);

// ---------------------------------------------------------------
// Shared-hosting override: if config/local.php exists (copied from
// config/local.php.example), load it first so its putenv() calls are
// available to everything below. Safe to skip entirely on a VPS where
// real environment variables are already set.
// ---------------------------------------------------------------
if (is_file(__DIR__ . '/local.php')) {
    require_once __DIR__ . '/local.php';
}

// ---------------------------------------------------------------
// General app configuration
// ---------------------------------------------------------------
define('APP_NAME', 'Multi-Shop Management System');
define('APP_URL', getenv('APP_URL') ?: 'http://localhost');
define('APP_ENV', getenv('APP_ENV') ?: 'production'); // 'local' enables verbose errors

define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', '/uploads/');

// Session lifetime (seconds) of inactivity before auto logout
define('SESSION_TIMEOUT', 30 * 60);

if (APP_ENV === 'local') {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
}

// ---------------------------------------------------------------
// Secure session bootstrap
// ---------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $secure,   // only sent over HTTPS in production
        'httponly' => true,      // not accessible to JavaScript — mitigates XSS session theft
        'samesite' => 'Lax',     // CSRF mitigation
    ]);

    session_start();
}

// Enforce inactivity timeout
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
    $_SESSION = [];
    session_destroy();
    header('Location: ' . APP_URL . '/public/auth/login.php?timeout=1');
    exit;
}
$_SESSION['last_activity'] = time();

// Regenerate session ID periodically to mitigate session fixation
if (empty($_SESSION['created_at'])) {
    $_SESSION['created_at'] = time();
} elseif (time() - $_SESSION['created_at'] > 15 * 60) {
    session_regenerate_id(true);
    $_SESSION['created_at'] = time();
}

require_once __DIR__ . '/../includes/security_headers.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
