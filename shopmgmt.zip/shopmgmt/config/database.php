<?php
/**
 * Database connection (PDO / MySQL).
 *
 * Credentials are read from environment variables so nothing sensitive
 * is committed to source control. Set these in your server config
 * (Apache vhost SetEnv, php-fpm pool, .env loader, etc.) — never hardcode
 * them here.
 *
 *   DB_HOST, DB_NAME, DB_USER, DB_PASS, DB_PORT (optional, default 3306)
 */

declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $host = getenv('DB_HOST') ?: '127.0.0.1';
    $port = getenv('DB_PORT') ?: '3306';
    $name = getenv('DB_NAME') ?: 'shop_management';
    $user = getenv('DB_USER') ?: '';
    $pass = getenv('DB_PASS') ?: '';

    if ($user === '') {
        // Fail loudly rather than silently connecting with blank creds.
        throw new RuntimeException(
            'Database credentials are not configured. Set DB_HOST, DB_NAME, DB_USER, DB_PASS as environment variables.'
        );
    }

    $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";

    try {
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements — SQL injection protection
        ]);
    } catch (PDOException $e) {
        error_log('DB connection failed: ' . $e->getMessage());
        http_response_code(500);
        die('A system error occurred. Please try again later.');
    }

    return $pdo;
}
