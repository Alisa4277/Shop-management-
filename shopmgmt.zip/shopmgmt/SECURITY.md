# Security & Firewall Guide

Security here has two layers. The **application layer** is code in this repo
and is already implemented. The **infrastructure layer** lives on your server
and network — no amount of PHP code can substitute for it, so treat this
section as a deployment checklist, not optional extras.

---

## 1. Application-layer security (already implemented)

| Area | Implementation |
|---|---|
| Passwords | `password_hash()` / `password_verify()` (bcrypt), transparent rehash on cost upgrade |
| SQL injection | 100% PDO prepared statements, `PDO::ATTR_EMULATE_PREPARES => false` |
| XSS | All dynamic output passed through `e()` (htmlspecialchars) |
| CSRF | Random token per session, verified on every POST via `csrf_verify()` |
| Session hijacking | HttpOnly + SameSite=Lax cookies, ID regenerated on login and periodically, inactivity timeout |
| Brute force | Login lockout after 5 failed attempts (15 min cooldown), generic error messages that don't reveal whether an email exists |
| File uploads | Real MIME-type check (not extension), size cap, randomized filenames, PHP execution disabled inside `/uploads` |
| Access control | `require_role()` gate on every protected page; `can_access_shop()` scopes managers/cashiers to their own shop |
| Secrets | DB and (later) M-Pesa credentials read from environment variables — never committed to code |
| Audit trail | `activity_logs` table records logins, failed logins, and data changes |
| HTTP headers | CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, HSTS (`includes/security_headers.php`) |
| Directory exposure | `config/`, `includes/`, `database/` return 403 directly; `public/` blocks directory listing and dotfiles |

---

## 2. Infrastructure-layer security (you set this up on the server)

### Network firewall
Restrict inbound traffic to only what's needed:
- Allow: **443** (HTTPS), **80** (HTTP → redirect to HTTPS only), **22** (SSH, ideally from a fixed IP/VPN only)
- Deny everything else, including **3306** (MySQL) from the public internet — MySQL should only accept connections from `127.0.0.1` or an internal private network, never 0.0.0.0.
- On Ubuntu/Debian: `ufw allow 443; ufw allow 80; ufw allow from <your-ip> to any port 22; ufw enable`
- On a cloud host (AWS/GCP/DigitalOcean/etc.), mirror this in the security-group/firewall rules, not just the OS firewall — that's your real first line of defense.

### TLS/HTTPS
- Install a certificate (Let's Encrypt/Certbot is free and auto-renewing) and force all traffic to HTTPS. Uncomment the HTTPS redirect in `public/.htaccess` once the cert is live.
- Without HTTPS, session cookies, login credentials, and M-Pesa phone numbers all travel in plaintext — this is not optional for a payments-handling system.

### Web Application Firewall (WAF)
Sits in front of the app and filters malicious requests before they reach PHP:
- **Managed option**: Cloudflare (free tier includes a WAF, DDoS protection, and bot filtering) — easiest to set up.
- **Self-hosted option**: ModSecurity with the OWASP Core Rule Set on Apache/Nginx.
- A WAF catches things app code can miss: SQL-injection payloads in headers, scanner traffic, known exploit signatures, and layer-7 DDoS attempts.

### Database hardening
- Create a dedicated MySQL user for this app with grants limited to the `shop_management` database only (`SELECT, INSERT, UPDATE, DELETE` — not `DROP`, `GRANT`, or global privileges). Never point the app at `root`.
- Bind MySQL to `127.0.0.1` (`bind-address` in `my.cnf`) unless the app and DB are genuinely on separate hosts, in which case use a private network/VPC, not a public IP.
- Enable MySQL's own audit/general query log if you need forensic detail beyond `activity_logs`.

### Brute force / intrusion prevention at the OS level
- `fail2ban` watching your web server and SSH logs — bans an IP after repeated failed logins or scan patterns. This complements (doesn't replace) the app-level lockout in `attempt_login()`.

### Rate limiting at the web server
- Nginx: `limit_req_zone` on `/public/auth/login_process.php` and any M-Pesa STK-push trigger endpoint, so a script can't hammer them faster than the app-level lockout can react.
- Apache: `mod_evasive` serves the same purpose.

### M-Pesa-specific hardening (relevant once Phase 2 lands)
- Whitelist Safaricom's callback IP ranges at the firewall/WAF level for your STK-push callback URL — don't leave it open to arbitrary POSTs.
- Verify the callback payload structure server-side before trusting it (check `CheckoutRequestID` exists in your `mpesa_transactions` table before marking anything as paid).
- Store Consumer Key/Secret and Passkey in environment variables (already the pattern used for DB creds) — never in a committed `.env` or in source.

### Patching & backups
- Keep PHP, MySQL, and the OS on supported versions with security patches applied promptly — most real-world breaches exploit known, already-patched CVEs.
- Automated, encrypted, off-server database backups (daily at minimum, given this handles payments and stock data). Test restores periodically — an untested backup is not a backup.

### Monitoring
- Ship server and app logs (`error_log`, `activity_logs`, web server access logs) somewhere you'll actually look at them — even a simple daily digest email of failed-login spikes or 5xx errors catches problems early.

---

## Summary: what's code vs. what's infrastructure

Everything in **Section 1** is done and lives in this repo. Everything in
**Section 2** has to be configured on whatever server/hosting you deploy to —
I can write you exact `ufw`/Nginx/Apache config snippets for your specific
host if you tell me what you're deploying to (shared hosting, a VPS like
DigitalOcean/Linode, or a cloud provider like AWS/GCP).
