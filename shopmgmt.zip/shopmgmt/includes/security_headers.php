<?php
declare(strict_types=1);

/**
 * Sends security-related HTTP headers on every request.
 * Included from config/config.php so it runs before any output.
 */

// Prevent the browser from MIME-sniffing responses into a different content type
header('X-Content-Type-Options: nosniff');

// Prevent the site from being embedded in an iframe elsewhere (clickjacking protection)
header('X-Frame-Options: DENY');

// Limit how much referrer info is sent to other sites
header('Referrer-Policy: strict-origin-when-cross-origin');

// Restrict browser features this app doesn't need
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

// Content-Security-Policy: only allow scripts/styles/images from same origin.
// Tighten further once you know your exact CDN needs (e.g. Chart.js host).
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self';");

// Force HTTPS for the next 6 months once you're actually serving over HTTPS.
// Only send this when the request itself was HTTPS, so local HTTP dev doesn't break.
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    header('Strict-Transport-Security: max-age=15552000; includeSubDomains');
}

// Remove headers that leak stack details (belt-and-braces; also set in php.ini)
header_remove('X-Powered-By');
