<?php $user = current_user(); ?>
<div class="topbar">
  <div>
    <button class="menu-toggle btn btn-outline" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
    <strong><?= e($pageTitle ?? 'Dashboard') ?></strong>
  </div>
  <div style="display:flex; align-items:center; gap:12px;">
    <span class="badge badge-muted"><?= e(ucwords(str_replace('_', ' ', $user['role']))) ?></span>
    <span><?= e($user['full_name']) ?></span>
  </div>
</div>
<?php foreach (flash_get() as $f): ?>
  <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
<?php endforeach; ?>
