<?php
/**
 * Included from inside pages after require_role().
 * Expects $activePage to be set by the including page for highlighting.
 */
$role = $_SESSION['role'] ?? '';
$activePage = $activePage ?? '';

$navByRole = [
    'super_admin' => [
        ['label' => 'Dashboard', 'href' => '/public/admin/dashboard.php', 'key' => 'dashboard', 'icon' => '📊'],
        ['label' => 'Shops', 'href' => '/public/admin/shops.php', 'key' => 'shops', 'icon' => '🏬'],
        ['label' => 'Products', 'href' => '/public/admin/products.php', 'key' => 'products', 'icon' => '📦'],
        ['label' => 'Users', 'href' => '/public/admin/users.php', 'key' => 'users', 'icon' => '👥'],
        ['label' => 'Reports', 'href' => '/public/admin/reports.php', 'key' => 'reports', 'icon' => '📈'],
        ['label' => 'Settings', 'href' => '/public/admin/settings.php', 'key' => 'settings', 'icon' => '⚙️'],
    ],
    'shop_manager' => [
        ['label' => 'Dashboard', 'href' => '/public/manager/dashboard.php', 'key' => 'dashboard', 'icon' => '📊'],
        ['label' => 'Stock', 'href' => '/public/manager/stock.php', 'key' => 'stock', 'icon' => '📦'],
        ['label' => 'Employees', 'href' => '/public/manager/employees.php', 'key' => 'employees', 'icon' => '👥'],
        ['label' => 'Reports', 'href' => '/public/manager/reports.php', 'key' => 'reports', 'icon' => '📈'],
    ],
    'cashier' => [
        ['label' => 'POS', 'href' => '/public/cashier/pos.php', 'key' => 'pos', 'icon' => '🧾'],
        ['label' => 'My Sales', 'href' => '/public/cashier/sales.php', 'key' => 'sales', 'icon' => '💰'],
    ],
    'storekeeper' => [
        ['label' => 'Dashboard', 'href' => '/public/storekeeper/dashboard.php', 'key' => 'dashboard', 'icon' => '📊'],
        ['label' => 'Stock', 'href' => '/public/storekeeper/stock.php', 'key' => 'stock', 'icon' => '📦'],
        ['label' => 'Transfers', 'href' => '/public/storekeeper/transfers.php', 'key' => 'transfers', 'icon' => '🔄'],
    ],
];

$items = $navByRole[$role] ?? [];
?>
<aside class="sidebar" id="sidebar">
  <div class="brand">🏬 <?= e(APP_NAME) ?></div>
  <nav>
    <?php foreach ($items as $item): ?>
      <a href="<?= APP_URL . e($item['href']) ?>" class="<?= $activePage === $item['key'] ? 'active' : '' ?>">
        <span><?= $item['icon'] ?></span> <?= e($item['label']) ?>
      </a>
    <?php endforeach; ?>
    <a href="<?= APP_URL ?>/public/auth/logout.php" style="margin-top:16px; border-top:1px solid var(--border); padding-top:16px;">
      <span>🚪</span> Logout
    </a>
  </nav>
</aside>
