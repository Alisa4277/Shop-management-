<?php
declare(strict_types=1);

/**
 * Parses an uploaded CSV file into an array of associative rows keyed by
 * the header row. No external dependency required.
 */
function parse_csv_file(string $path): array
{
    $rows = [];
    $handle = fopen($path, 'r');
    if ($handle === false) {
        throw new RuntimeException('Could not open the uploaded file.');
    }

    // Strip a UTF-8 BOM if present (common when files are exported from Excel)
    $bom = fread($handle, 3);
    if ($bom !== "\xEF\xBB\xBF") {
        rewind($handle);
    }

    $header = fgetcsv($handle);
    if ($header === false) {
        fclose($handle);
        throw new RuntimeException('The file appears to be empty.');
    }
    $header = array_map(static fn($h) => strtolower(trim((string) $h)), $header);

    while (($line = fgetcsv($handle)) !== false) {
        if (count($line) === 1 && trim((string) $line[0]) === '') {
            continue; // skip blank lines
        }
        $row = [];
        foreach ($header as $i => $col) {
            $row[$col] = isset($line[$i]) ? trim((string) $line[$i]) : '';
        }
        $rows[] = $row;
    }
    fclose($handle);
    return $rows;
}

/**
 * Parses an uploaded .xlsx file. Requires phpoffice/phpspreadsheet
 * (composer require phpoffice/phpspreadsheet) — if it isn't installed,
 * throws a clear error telling the admin to install it or use CSV instead.
 */
function parse_xlsx_file(string $path): array
{
    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (is_file($autoload)) {
        require_once $autoload;
    }

    if (!class_exists(\PhpOffice\PhpSpreadsheet\IOFactory::class)) {
        throw new RuntimeException(
            'Excel (.xlsx) import requires the PhpSpreadsheet library. ' .
            'Run "composer install" on the server (composer.json already lists it), ' .
            'or export your file as CSV and upload that instead.'
        );
    }

    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($path);
    $sheet = $spreadsheet->getActiveSheet();
    $data = $sheet->toArray(null, true, true, false);

    if (empty($data)) {
        throw new RuntimeException('The spreadsheet appears to be empty.');
    }

    $header = array_map(static fn($h) => strtolower(trim((string) $h)), array_shift($data));

    $rows = [];
    foreach ($data as $line) {
        $isBlank = true;
        $row = [];
        foreach ($header as $i => $col) {
            $value = isset($line[$i]) ? trim((string) $line[$i]) : '';
            if ($value !== '') {
                $isBlank = false;
            }
            $row[$col] = $value;
        }
        if (!$isBlank) {
            $rows[] = $row;
        }
    }
    return $rows;
}

/**
 * Validates and inserts one parsed product row. Returns ['status' => 'imported'|'skipped', 'message' => ...]
 */
function import_product_row(PDO $pdo, array $row): array
{
    $sku          = trim((string) ($row['sku'] ?? ''));
    $barcode      = trim((string) ($row['barcode'] ?? '')) ?: null;
    $name         = trim((string) ($row['name'] ?? ''));
    $categoryName = trim((string) ($row['category_name'] ?? ''));
    $description  = trim((string) ($row['description'] ?? '')) ?: null;
    $buyingPrice  = $row['buying_price'] ?? null;
    $sellingPrice = $row['selling_price'] ?? null;
    $minStock     = $row['min_stock_level'] ?? 5;

    if ($sku === '' || $name === '') {
        return ['status' => 'error', 'message' => 'Missing required sku or name.'];
    }
    if (!is_numeric($buyingPrice) || !is_numeric($sellingPrice) || (float) $buyingPrice < 0 || (float) $sellingPrice < 0) {
        return ['status' => 'error', 'message' => 'buying_price / selling_price must be non-negative numbers.'];
    }

    // Skip rather than overwrite existing SKUs — bulk import is for adding new stock lines
    $existing = $pdo->prepare('SELECT id FROM products WHERE sku = :sku');
    $existing->execute(['sku' => $sku]);
    if ($existing->fetch()) {
        return ['status' => 'skipped', 'message' => "SKU '{$sku}' already exists."];
    }

    $categoryId = null;
    if ($categoryName !== '') {
        $catStmt = $pdo->prepare('SELECT id FROM categories WHERE name = :name');
        $catStmt->execute(['name' => $categoryName]);
        $cat = $catStmt->fetch();
        if ($cat) {
            $categoryId = (int) $cat['id'];
        } else {
            $pdo->prepare('INSERT INTO categories (name) VALUES (:name)')->execute(['name' => $categoryName]);
            $categoryId = (int) $pdo->lastInsertId();
        }
    }

    try {
        $pdo->prepare(
            "INSERT INTO products (sku, barcode, name, category_id, description, buying_price, selling_price, min_stock_level, status)
             VALUES (:sku, :barcode, :name, :category_id, :description, :buying, :selling, :min_stock, 'active')"
        )->execute([
            'sku'         => $sku,
            'barcode'     => $barcode,
            'name'        => $name,
            'category_id' => $categoryId,
            'description' => $description,
            'buying'      => (float) $buyingPrice,
            'selling'     => (float) $sellingPrice,
            'min_stock'   => (int) $minStock,
        ]);
        return ['status' => 'imported', 'message' => null];
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            return ['status' => 'error', 'message' => "Duplicate barcode '{$barcode}'."];
        }
        error_log('import_product_row error: ' . $e->getMessage());
        return ['status' => 'error', 'message' => 'Database error while inserting this row.'];
    }
}
