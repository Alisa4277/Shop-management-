<?php
declare(strict_types=1);

/** Escape output for safe HTML rendering (XSS prevention). */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function format_money(float $amount): string
{
    return 'KSh ' . number_format($amount, 2);
}

/** Set a one-time flash message shown on the next page load. */
function flash_set(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

/** Retrieve and clear all pending flash messages. */
function flash_get(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

/** Redirect helper. */
function redirect(string $path): void
{
    header('Location: ' . APP_URL . $path);
    exit;
}

/** Send the correct dashboard path for a given role. */
function dashboard_path_for_role(string $role): string
{
    return match ($role) {
        'super_admin'  => '/public/admin/dashboard.php',
        'shop_manager' => '/public/manager/dashboard.php',
        'cashier'      => '/public/cashier/pos.php',
        'storekeeper'  => '/public/storekeeper/dashboard.php',
        default        => '/public/auth/login.php',
    };
}

/** Basic phone normalization for Kenyan numbers, e.g. 0712345678 -> 254712345678. */
function normalize_phone(string $phone): string
{
    $phone = preg_replace('/\D/', '', $phone) ?? '';
    if (str_starts_with($phone, '0')) {
        $phone = '254' . substr($phone, 1);
    } elseif (str_starts_with($phone, '+254')) {
        $phone = substr($phone, 1);
    } elseif (!str_starts_with($phone, '254')) {
        $phone = '254' . $phone;
    }
    return $phone;
}

function is_valid_kenyan_phone(string $phone): bool
{
    return (bool) preg_match('/^254(7|1)\d{8}$/', normalize_phone($phone));
}
