<?php
declare(strict_types=1);

// =================================================================
// Authentication & Role-Based Access Control
// =================================================================

const MAX_LOGIN_ATTEMPTS = 5;
const LOGIN_LOCKOUT_SECONDS = 15 * 60;

/**
 * Attempt to log a user in. Returns true on success, false on failure.
 * Applies basic rate limiting per email to slow brute-force attempts.
 */
function attempt_login(string $email, string $password): array
{
    $pdo = db();

    // --- basic throttling, tracked in-session per email hash ---
    $key = 'login_attempts_' . md5(strtolower($email));
    $attempts = $_SESSION[$key] ?? ['count' => 0, 'locked_until' => 0];

    if ($attempts['locked_until'] > time()) {
        $wait = $attempts['locked_until'] - time();
        return ['success' => false, 'message' => "Too many failed attempts. Try again in {$wait} seconds."];
    }

    $stmt = $pdo->prepare(
        "SELECT u.*, r.name AS role_name, r.max_discount_percent
         FROM users u
         JOIN roles r ON r.id = u.role_id
         WHERE u.email = :email
         LIMIT 1"
    );
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    if (!$user || $user['status'] !== 'active' || !password_verify($password, $user['password_hash'])) {
        $attempts['count']++;
        if ($attempts['count'] >= MAX_LOGIN_ATTEMPTS) {
            $attempts['locked_until'] = time() + LOGIN_LOCKOUT_SECONDS;
            $attempts['count'] = 0;
        }
        $_SESSION[$key] = $attempts;

        log_activity(null, 'login_failed', "Failed login attempt for {$email}");
        return ['success' => false, 'message' => 'Invalid email or password.'];
    }

    // success — clear throttle state
    unset($_SESSION[$key]);

    // Re-hash transparently if PHP's default cost factor has changed
    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password_hash = :h WHERE id = :id")
            ->execute(['h' => $newHash, 'id' => $user['id']]);
    }

    session_regenerate_id(true);

    $_SESSION['user_id']    = (int) $user['id'];
    $_SESSION['full_name']  = $user['full_name'];
    $_SESSION['email']      = $user['email'];
    $_SESSION['role']       = $user['role_name'];
    $_SESSION['shop_id']    = $user['shop_id'] !== null ? (int) $user['shop_id'] : null;
    $_SESSION['max_discount'] = (float) $user['max_discount_percent'];

    $pdo->prepare("UPDATE users SET last_login_at = NOW() WHERE id = :id")
        ->execute(['id' => $user['id']]);

    log_activity((int) $user['id'], 'login', 'User logged in');

    return ['success' => true, 'role' => $user['role_name']];
}

function logout(): void
{
    if (isset($_SESSION['user_id'])) {
        log_activity((int) $_SESSION['user_id'], 'logout', 'User logged out');
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie('PHPSESSID', '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    return [
        'id'          => (int) $_SESSION['user_id'],
        'full_name'   => $_SESSION['full_name'],
        'email'       => $_SESSION['email'],
        'role'        => $_SESSION['role'],
        'shop_id'     => $_SESSION['shop_id'],
        'max_discount'=> $_SESSION['max_discount'],
    ];
}

function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

/** Redirect to login if not authenticated. Call at the top of every protected page. */
function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: ' . APP_URL . '/public/auth/login.php');
        exit;
    }
}

/**
 * Restrict a page to specific roles.
 * Usage: require_role(['super_admin', 'shop_manager']);
 */
function require_role(array $allowedRoles): void
{
    require_login();
    if (!in_array($_SESSION['role'], $allowedRoles, true)) {
        http_response_code(403);
        die('403 — You do not have permission to access this page.');
    }
}

/** True if the logged-in user may act on the given shop (super_admin = all shops). */
function can_access_shop(int $shopId): bool
{
    if (!is_logged_in()) {
        return false;
    }
    if ($_SESSION['role'] === 'super_admin') {
        return true;
    }
    return (int) ($_SESSION['shop_id'] ?? 0) === $shopId;
}

function log_activity(?int $userId, string $action, ?string $description = null): void
{
    try {
        db()->prepare(
            "INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent)
             VALUES (:uid, :action, :desc, :ip, :ua)"
        )->execute([
            'uid'    => $userId,
            'action' => $action,
            'desc'   => $description,
            'ip'     => $_SERVER['REMOTE_ADDR'] ?? null,
            'ua'     => $_SERVER['HTTP_USER_AGENT'] ?? null,
        ]);
    } catch (Throwable $e) {
        error_log('Failed to write activity log: ' . $e->getMessage());
    }
}

// -----------------------------------------------------------------
// Password reset
// -----------------------------------------------------------------

/** Generates and stores a reset token, returns the raw token to email/SMS to the user. */
function create_password_reset(string $email): ?string
{
    $pdo = db();
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email AND status = 'active'");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    // Always behave the same whether or not the email exists, to avoid leaking
    // which addresses are registered.
    $token = bin2hex(random_bytes(32));

    if ($user) {
        $pdo->prepare(
            "UPDATE users SET reset_token = :t, reset_token_expires_at = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = :id"
        )->execute(['t' => hash('sha256', $token), 'id' => $user['id']]);
        return $token;
    }
    return null; // caller shows a generic "if that email exists..." message either way
}

function reset_password(string $token, string $newPassword): bool
{
    $pdo = db();
    $hashed = hash('sha256', $token);

    $stmt = $pdo->prepare(
        "SELECT id FROM users WHERE reset_token = :t AND reset_token_expires_at > NOW()"
    );
    $stmt->execute(['t' => $hashed]);
    $user = $stmt->fetch();

    if (!$user) {
        return false;
    }

    $pdo->prepare(
        "UPDATE users SET password_hash = :p, reset_token = NULL, reset_token_expires_at = NULL WHERE id = :id"
    )->execute([
        'p'  => password_hash($newPassword, PASSWORD_DEFAULT),
        'id' => $user['id'],
    ]);

    log_activity((int) $user['id'], 'password_reset', 'Password reset via token');
    return true;
}
