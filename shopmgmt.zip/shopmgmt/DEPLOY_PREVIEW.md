# Deploying a Preview (Free Hosting)

This gets the system live on a free host so you can click through it before
we build M-Pesa. Free hosts don't give SSH/CLI access, so this uses the
web-based setup path instead of `database/create_admin.php`.

## 1. Pick a host
Good free options right now (no credit card required): **InfinityFree**
(infinityfree.com) or **Byet Host** (byet.host). Both give PHP 8.3, MySQL,
free SSL, and a cPanel-style file manager + phpMyAdmin. Sign up and create
a new hosting account/subdomain.

## 2. Create the database
In your host's control panel:
1. Open **MySQL Databases** and create a new database (note the full name —
   free hosts usually prefix it, e.g. `epiz_12345678_shopmgmt`).
2. Create a database user and password, attach it to that database with
   full privileges.
3. Open **phpMyAdmin**, select the new database, go to **Import**, and
   upload `database/schema.sql`. This creates all the tables and seeds
   the roles.

## 3. Configure the app
1. Copy `config/local.php.example` to `config/local.php`.
2. Fill in the DB name/user/password from step 2, your site's URL, and a
   long random `SETUP_KEY` (this replaces the CLI admin-creation step).
   A quick way to generate one: `php -r "echo bin2hex(random_bytes(24));"`
   or just mash the keyboard for 30+ random characters.
3. Leave `APP_ENV=local` for now — it shows PHP errors on screen, which is
   useful for the first-time preview. Switch to `production` once things
   are working.

## 4. Upload the files
Upload the **entire `shopmgmt/` folder contents** (not the folder itself —
its contents) into your host's web root (usually `htdocs/` or
`public_html/`). You should end up with `htdocs/config/`, `htdocs/public/`,
`htdocs/includes/`, etc. all as siblings. Use the file manager's zip-upload
option if available — upload the whole zip and extract it there rather
than uploading hundreds of files one by one.

## 5. Create your Super Admin account
Visit:
```
https://yoursite.example.com/public/setup_admin.php?key=YOUR_SETUP_KEY
```
Fill in the form once. This page permanently refuses to run again once a
Super Admin exists, but **delete `public/setup_admin.php` afterwards** for
good measure — one less file exposed.

## 6. Log in
```
https://yoursite.example.com/public/auth/login.php
```
Select the "Super Admin" portal tab and sign in with the account you just
created.

## Known limitations of this preview setup
- **No SSH** on most free hosts — bulk product import via `.xlsx` needs
  `composer install` to fetch PhpSpreadsheet, which needs shell access.
  CSV import works fine without it. If you want `.xlsx` too, look for a
  host with SSH (many $2–5/mo shared plans include it), or ask me and
  I'll vendor PhpSpreadsheet's files directly into the repo instead of
  relying on Composer.
- **Free-tier resource limits** — fine for clicking through the UI and
  demoing to people; not meant for real transaction volume.
- **M-Pesa Daraja API** requires a publicly reachable HTTPS callback URL,
  which this preview gives you — good, that means once we build the
  M-Pesa integration you can actually test STK Push against Safaricom's
  sandbox right on this same site.
